This software is  specially designed  for All college students by me. Since i 
know that  even today most of  the colleges teach C  programming language  in
one of the oldest iDe(Integrated devleopment Environment) availagble i.e.TurboC
which is in no way compatible with the latest version of windows like windows 7.
One of the greatest problem of it is not availability of fullscreen mode. But in
64bit it doesn't run at all because of unavailability of 16bit dos Subsystem in it.

So it is a great problem for students to hunt for a new iDe and cope with it.
So i now made it possible for them to use the age old turbo C which most students
and teachers are familiar with, to be able to run in windows 7 or vista may it be
32bit or 64bit, with the help of some utilities like Dosbox and other usefull tools.

Now you can enjoy your programming in your favourite TurboC++3.0 without getting
bothered by incompatibility issues with windows.

I am NeutroN Vegeto Striker.Dbz, you can contact me regarding an installation issues
or program issues via mail, my email id is striker.dbz@hotmail.com and even through
facebook you can contact me also, just goto http://www.facebook.com/neutron.vegetostriker/.

For more information please visit my website http://nvstech.weebly.com

Legal Stuff:
Microsoft Windows 7(R) and Vista(R) are registered trademarks of Microsoft Corporation.

TurboC++ 3.0 is the registered trademark of Borland Corporation.

Microsoft Corporation or Borland Corporation are not associated with this project. This 
is effort for the community by me to help budding developers. Turbo C++ 3.0 is still a 
copyright entity of Borland Corporation.  

Apart from Turbo C++ 3.0 and msvc runtimes, rest of code in it is under GPL.

This software is free to use, and to distribute this to anyone
just make sure that you also distribute this license to them.

Happy Programming.